void fail(const char *);
