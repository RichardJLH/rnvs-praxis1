#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define BACKLOG 10

void fail(const char *const message) {
  perror(message);
  exit(EXIT_FAILURE);
}

struct addrinfo *get_address_info(const char *const ip,
                                  const char *const port) {
  struct addrinfo *res;
  struct addrinfo hints = {
      .ai_family = AF_INET,
  };

  const int error_code = getaddrinfo(ip, port, &hints, &res);
  if (error_code != 0) {
    fail("Error parsing host/port");
  }

  return res;
}
int setup_socket(const struct addrinfo *const address_info) {
  const int s = socket(address_info->ai_family, address_info->ai_socktype,
                       address_info->ai_protocol);

  const int optval = 1;
  setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

  return s;
}
void bind_socket(const int socket, const struct addrinfo *const address_info) {
  const int error_code =
      bind(socket, address_info->ai_addr, address_info->ai_addrlen);
  if (error_code != 0) {
    fail("Error binding to socket");
  }
}
void listen_socket(const int socket) {
  const int error_code = listen(socket, BACKLOG);
  if (error_code == -1) {
    perror("Error listening to socket");
  }
}

int main(int n, char **arg) {
  if (n != 3)
    return -1;

  struct addrinfo *const address_info = get_address_info(arg[1], arg[2]);
  const int s = setup_socket(address_info);
  bind_socket(s, address_info);
  freeaddrinfo(address_info);

  listen_socket(s);

  const char *reply = "Reply\r\n\r\n";
  const unsigned long reply_size = strlen(reply) * sizeof(char);

  while (true) {
    struct sockaddr_storage their_addr;
    socklen_t addr_size = sizeof(their_addr);

    const int s1 = accept(s, (struct sockaddr *)&their_addr, &addr_size);
    if (s1 == -1) {
      fprintf(stderr, "Error accepting connection");
      exit(EXIT_FAILURE);
    }

    char received[512];
    size_t received_end = 0;
    while (true) {
      const ssize_t received_bytes =
          recv(s1, received + received_end, sizeof(received) - received_end, 0);
      if (received_bytes == -1) {
        perror("Receiving bytes");
        break;
      }
      if (received_bytes == 0) {
        break;
      }

      received_end += received_bytes;

      while (true) {
        received[received_end] = '\0';
        const char *const terminator = "\r\n\r\n";
        const char *end = strstr(received, terminator);
        if (end == NULL)
          break;

        end += strlen(terminator);

        send(s1, reply, reply_size, 0);

        const size_t packet_len = end - received;
        memmove(received, received + packet_len, received_end - packet_len);
        received_end -= packet_len;
      }
    }
    close(s1);
  }

  return 0;
}
